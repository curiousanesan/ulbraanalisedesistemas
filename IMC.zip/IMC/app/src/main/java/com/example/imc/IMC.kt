package com.example.imc

import android.os.Parcel
import android.os.Parcelable
import kotlin.math.roundToInt


class IMC(var nome: String?, var peso: Float, var altura: Float, var imc: Float) :Parcelable {


    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readFloat(),
        parcel.readFloat(),
        parcel.readFloat()
    ) {
    }

    constructor(name: String, peso: Float, altura: Float) : this(name,peso,altura,0.0f)

    fun calcular() : String{

        val alt =altura/100
        val calc = peso / (alt*alt)
        val msg =when (calc){
            in 0 ..16  -> "Você está com Magreza grave.\n Seu peso é: $peso.\n Sua altura é: $altura "
            in 16 ..17 ->"Você está com Magreza moderada.\n Seu peso é: $peso.\n Sua altura é: $altura"
            in 17 ..19 ->"Você está com Magreza leve.\n Seu peso é: $peso.\n Sua altura é: $altura"
            in 19 ..25 ->"Você está Saudável.\n Seu peso é: $peso.\n Sua altura é: $altura"
            in 25 ..30 ->"Você está com Sobrepeso.\n Seu peso é: $peso.\n Sua altura é: $altura"
            in 30 ..35 ->"Você está com Obesidade\n I. Seu peso é: $peso.\n Sua altura é: $altura"
            in 35 ..40 ->"Você está com Obesidade\n II. Seu peso é: $peso.\n Sua altura é: $altura"

            else -> "Você está com Obesidade Morbida."
        }
        imc = calc
        imc = ((calc * 100.0).roundToInt() / 100.0).toFloat()
        return msg
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(nome)
        parcel.writeFloat(peso)
        parcel.writeFloat(altura)
        parcel.writeFloat(imc)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<IMC> {
        override fun createFromParcel(parcel: Parcel): IMC {
            return IMC(parcel)
        }

        override fun newArray(size: Int): Array<IMC?> {
            return arrayOfNulls(size)
        }
    }


}